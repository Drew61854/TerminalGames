# Terminal Games

Are you stuck on camera duty, bored out of your mind? Are you tired of babysitting the loot? Then look no further than Terminal Games!
With Terminal Games, you can sit comfortably in the satfey of the ship and entertain yourself with state-of-the-art video game technology such as:

## BlackJack

The classic card game, now digitized! Gamble your credits or play for free, see if you can beat the house! Do you not know when to double and when to hit? Well don't worry, because you can't double. Why? Because The Company always wins. 

## Numbers

A game often used to teach computer science brought directly to your computer, no science needed. Guess a number 1 to 1000 and get feedback on if your guess was too high or too low. You get ten guesses, can you solve this puzzle?


## More to Come

The Company has invested a lot of money(5 credits) into this program, so our engineers are hard at work to bring you more games! Check back soon to keep up-to-date with all the exciting content Terminal Games has to offer. 